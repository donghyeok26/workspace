import java.util.Scanner;
public class Coding_16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean stop = false;
		int i = 0;
		while(!stop) {
		
		Scanner sc = new Scanner(System.in);
		String a = sc.next();
		
		
		Coding_16_on turn = new Coding_16_on(); 
		if(a.equals("����")) {
			String on = turn.turn();
			System.out.println(on);
		}
		
		
		Coding_16_off turn1 = new Coding_16_off(); 
		if(a.equals("����")) {
			String off = turn1.turn();
			System.out.println(off);
		}
		
		Coding_16_vol vol1 = new Coding_16_vol();
		
		if(a.equals("+")) {
			i++;
			int vol2 = vol1.vol(i);
			System.out.println("������ �ö󰬽��ϴ�.");
			System.out.println(vol2);
		}	
		Coding_16_vold vold = new Coding_16_vold();
		
		if(a.equals("-")) {
			i--;
			int vol2 = vol1.vol(i);
			System.out.println("������ ���������ϴ�.");
			System.out.println(vol2);
		}	
	
		Coding_16_ch cha = new Coding_16_ch();
		if(a.equals("ä�μ���")){
			int ch = sc.nextInt();
		System.out.println(ch);
		System.out.println(ch+"ä�η� �̵��Ǿ����ϴ�");
		}
		continue;
	}
}
}