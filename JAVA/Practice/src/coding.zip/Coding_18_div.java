
public class Coding_18_div {
	public int div_sum (int num1, int num2) {
		int sum = num1 - num2;
		return sum;
	}
}
