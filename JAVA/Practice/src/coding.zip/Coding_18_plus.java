
public class Coding_18_plus {
	public int plus_sum (int num1,int num2) {
		int num = num1 + num2;
		return num;
	}
}
