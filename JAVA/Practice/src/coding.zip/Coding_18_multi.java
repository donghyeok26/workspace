
public class Coding_18_multi {
	public int multi_sum (int num1, int num2) {
		int num = num1 * num2;
		return num;
	}
}
