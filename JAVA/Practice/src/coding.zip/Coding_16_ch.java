
public class Coding_16_ch {
	public int ch(int i) {
		int ch = i;
		return ch;
	}
}
