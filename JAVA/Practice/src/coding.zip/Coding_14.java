
public class Coding_14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i;
		int j;
		for(i = 2 ; i <=9; i++) {
			System.out.println("***"+i + "��****");
			for (j =1; j <=9; j++) {
				System.out.println(i+"x"+j+"="+(i*j));
			}
		}
			
			
	}

}
