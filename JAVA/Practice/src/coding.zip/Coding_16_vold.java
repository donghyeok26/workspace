
public class Coding_16_vold {
	public int vold(int i) {
		int vold = 0;
		
			vold = i--;
		
		return vold;
	}
}
